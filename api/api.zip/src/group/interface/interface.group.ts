export interface Group{
    name: string,
    image: string,
    contractAddress: string
}