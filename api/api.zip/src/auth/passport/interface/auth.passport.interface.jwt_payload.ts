export interface JwtPayload {
    wallet: string
}